This release contains 2 versions of the APK for Android:

- BRouter_api28.apk is the version intended for upload on GooglePlay Store
  It is not fully functional due to security restrictions

- BRouter_api10.apk is the classic version that allows
  access to the waypoint databases of the map-tools (Locus/Osmand/Orux)
